import React from 'react';
import { render } from 'react-dom';

import Todos from './todos';

render(
  <Todos />,
  document.getElementById('app')
);
