import React from "react";
import logo from "./logo.svg";
import "./App.css";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import PersonList from "./components/PersonList";
import PersonInput from "./components/PersonInput";
import Home from "./components/Home";
import Contact from "./components/Contact";
import SingUp from "./components/SingUp";
import Notfound from "./components/Notfound";

function App() {
  return (
    <Router>
      <div>
        <h2>Welcome to Routing</h2>
        <nav>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
            <li>
              <Link to="/personList">Persons</Link>
            </li>
            <li>
              <Link to="/personInput/Jack">Person Input</Link>
            </li>
            <li>
              <Link to="/signUp">Sign Up</Link>
            </li>
          </ul>
        </nav>
        <Switch>
          <Route exact path="/" component={Home} />
          <Route path="/contact" component={Contact} />
          <Route path="/personList" component={PersonList} />
          <Route path="/personInput/:name" component={PersonInput} />
          <Route path="/signUp" component={SingUp} />
          <Route component={Notfound} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;
