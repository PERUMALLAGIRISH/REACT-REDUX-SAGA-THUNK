import React, { Component } from "react";

class Contact extends Component {
  render() {
    return <h2>Contact</h2>;
  }
}

export default Contact;
