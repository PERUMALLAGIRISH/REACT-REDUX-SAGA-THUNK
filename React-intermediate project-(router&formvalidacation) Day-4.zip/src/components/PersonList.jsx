import React, { Component } from "react";
import axios from "axios";

class PersonList extends Component {
  state = {
    persons: []
  };

  // LC hook , rest api calls when the component is mounted in DOM
  componentDidMount() {
    axios.get(`http://jsonplaceholder.typicode.com/users`).then(
      res => {
        this.setState({ persons: res.data });
      },
      err => {
        console.log(`Error occurred ${err}`);
      }
    );
  }

  render() {
    return (
      <ul>
        {this.state.persons.map(person => (
          <li key={person.id}>{person.name}</li>
        ))}
      </ul>
    );
  }
}

export default PersonList;
