import React, { Component } from "react";

class Home extends Component {
  render() {
    return <h2>Home</h2>;
  }
}

export default Home;
