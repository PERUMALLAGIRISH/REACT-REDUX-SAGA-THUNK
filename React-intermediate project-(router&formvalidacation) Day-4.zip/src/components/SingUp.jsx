import React, { Component } from "react";

class SingUp extends Component {
  state = {
    email: "",
    password: "",
    emailValid: false,
    passwordValid: false,
    formErrors: { email: "", password: "" },
    formValid: false // for the validity of the form
  };

  handleUserInput(event) {
    const name = event.target.name;
    const value = event.target.value;

    //console.log(name + value);

    this.setState({ [name]: value }, () => {
      this.validateField(name, value);
    });
  }

  validateField(fieldName, value) {
    let emailValid = this.state.emailValid;
    let passwordValid = this.state.passwordValid;
    let fieldValidationErrors = this.state.formErrors;

    switch (fieldName) {
      case "email":
        emailValid = value.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i);
        fieldValidationErrors.email = emailValid ? " " : "Is Invalid";
        console.log(fieldValidationErrors.email);
        break;
      case "password":
        passwordValid = value.length >= 6;
        fieldValidationErrors.password = passwordValid ? " " : "Is very short";
        console.log(fieldValidationErrors.password);
        break;
      default:
        break;
    }

    this.setState(
      {
        formErrors: fieldValidationErrors,
        emailValid: emailValid,
        passwordValid: passwordValid
      },
      this.validateForm
    );
  }

  validateForm() {
    this.setState({
      formValid: this.state.emailValid && this.state.passwordValid
    });
  }

  render() {
    return (
      <div>
        <form
          onSubmit={event => {
            event.preventDefault();
            this.props.history.push("/");
          }}
        >
          <h2>Sign Up</h2>
          <label>Email:</label>
          <input
            type="email"
            name="email"
            value={this.state.email}
            onChange={event => this.handleUserInput(event)}
          />
          <h3>{this.state.formErrors.email}</h3>
          <label>Password:</label>
          <input
            type="password"
            name="password"
            value={this.state.password}
            onChange={event => this.handleUserInput(event)}
          />
          <h3>{this.state.formErrors.password}</h3>
          <button type="submit" disabled={!this.state.formValid}>
            Sing Up
          </button>
        </form>
      </div>
    );
  }
}

export default SingUp;
