import React, { Component } from "react";

class Notfound extends Component {
  render() {
    return <h2>Url does not match</h2>;
  }
}

export default Notfound;
