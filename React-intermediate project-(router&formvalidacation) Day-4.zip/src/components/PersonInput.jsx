import React, { Component } from "react";
import axios from "axios";

class PersonInput extends Component {
  state = {
    name: ""
  };

  handleChange = event => {
    this.setState({ name: event.target.value });
  };

  handleSubmit = event => {
    event.preventDefault();

    const user = {
      name: this.state.name
    };

    axios
      .post(`http://jsonplaceholder.typicode.com/users`, { user })
      .then(res => {
        console.log(res);
        console.log(res.data);
      });
  };

  render() {
    console.log(this.props.match.params.name);
    return (
      <form onSubmit={this.handleSubmit}>
        <label>Person name:</label>
        <input type="text" name="name" onChange={this.handleChange} />
        <button type="submit">Add Person</button>
      </form>
    );
  }
}

export default PersonInput;
