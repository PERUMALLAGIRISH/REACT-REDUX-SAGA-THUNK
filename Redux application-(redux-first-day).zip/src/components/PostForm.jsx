import React, { Component } from "react";
import axios from "axios";

class PostForm extends Component {
  state = {
    title: "",
    body: ""
  };

  handleChange = event => {
    const name = event.target.name;
    const value = event.target.value;

    this.setState({ [name]: value });
  };

  handleSubmit = event => {
    event.preventDefault();

    const post = {
      title: this.state.title,
      body: this.state.body
    };

    axios.post(`http://jsonplaceholder.typicode.com/posts`,{post})
    .then(res => {
        console.log(res.data);
    })
  };

  render() {
    return (
      <div>
        <form onSubmit={this.handleSubmit}>
          <div>
            <label>Enter Title:</label>
            <input
              type="text"
              name="title"
              value={this.state.title}
              onChange={event => this.handleChange(event)}
            />
          </div>
          <div>
            <label>Enter Body:</label>
            <input
              type="text"
              name="body"
              value={this.state.body}
              onChange={event => this.handleChange(event)}
            />
          </div>
          <button>Submit</button>
        </form>
      </div>
    );
  }
}

export default PostForm;
