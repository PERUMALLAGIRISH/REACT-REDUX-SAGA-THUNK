import React, { Component } from "react";
import { fetchPosts } from "../actions/postActions";
import { connect } from "react-redux";
class Post extends Component {
  componentWillMount() {
    this.props.fetchPosts();
  }
  render() {
    return (
      <div>
        {this.props.posts.map(post => (
          <div key={post.id}>
            <h4>{post.title}</h4>
            <p>{post.body}</p>
          </div>
        ))}
      </div>
    );
  }
}
const mapStatetoProps = state => ({
  posts: state.posts.items
});
// map the state from the reducer to the props
export default connect(mapStatetoProps, { fetchPosts })(Post);
