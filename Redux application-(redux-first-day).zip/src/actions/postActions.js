import { FETCH_POSTS, NEW_POST } from "./types";
import axios from "axios";

// Action creators = Functions
export const fetchPosts = () => dispatch => {
  axios.get(`http://jsonplaceholder.typicode.com/posts`).then(res => {
    // action object , type and payload
    dispatch({
      type: FETCH_POSTS,
      payload: res.data
    });
  });
};
