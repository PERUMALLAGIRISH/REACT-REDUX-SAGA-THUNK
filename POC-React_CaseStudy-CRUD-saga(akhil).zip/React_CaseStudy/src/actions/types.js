//Action Types

export const FETCH_PRODUCTS = "FETCH_PRODUCTS";
export const ADD_PRODUCTS = "ADD_PRODUCTS";
export const DELETE_PRODUCTS = "DELETE_PRODUCTS";
export const EDIT_PRODUCTS = "EDIT_PRODUCTS";
