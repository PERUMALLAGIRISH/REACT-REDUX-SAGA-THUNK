import React, { Component } from "react";
import axios from "axios";
import logo from "./logo.svg";
import "./App.css";
import Products from "./Products";
import Basket from "./Basket";
import Filter from "./Filter";

class App extends Component {
  state = {
    size: "",
    sort: "",
    cartItems: [],
    filteredProducts: [],
    products: []
  };

  componentWillMount() {
    axios.get("http://localhost:8000/products").then(res => {
      this.setState({ products: res.data });
      this.listProducts(); // displaying the products in sorted order by id
    });
  }

  handleAddToCart = product => {
    this.setState(state => {
      const cartItems = state.cartItems;
      let productAlreadyInCart = false;

      cartItems.forEach(cp => {
        if (cp.id === product.id) {
          cp.count += 1;
          productAlreadyInCart = true;
        }
      });

      if (!productAlreadyInCart) {
        cartItems.push({ ...product, count: 1 });
        console.log(cartItems);
      }

      return { cartItems: cartItems };
    });
  };

  handleRemoveFromCart = product => {
    this.setState(state => {
      const cartItems = state.cartItems.filter(a => a.id !== product.id);
      return { cartItems: cartItems };
    });
  };

  handleSortChange = e => {
    this.setState({ sort: e.target.value });
    this.listProducts(); // sort logic
  };

  handleSizeChange = e => {
    this.setState({ size: e.target.value });
    this.listProducts(); // size logic
  };

  listProducts = () => {
    this.setState(state => {
      if (state.sort !== "") {
        state.products.sort(
          (a, b) =>
            state.sort === "lowestprice"
              ? a.price > b.price ? 1 : -1 // lowest to highest
              : a.price < b.price ? 1 : -1
        ); // highest to lowest
      } else {
        state.products.sort((a, b) => (a.id > b.id ? 1 : -1)); // id in ascending
      }

      if (state.size !== "") {
        return {
          filteredProducts: state.products.filter(
            a => a.availableSizes.indexOf(state.size.toUpperCase()) >= 0
          )
        };
      }

      return { filteredProducts: state.products };
    });
  };

  render() {
    return (
      <div className="container">
        <h1>E-commerce Application</h1>
        <hr />
        <div className="row">
          <div className="col-md-9">
            <Filter
              count={this.state.filteredProducts.length}
              handleSortChange={this.handleSortChange}
              handleSizeChange={this.handleSizeChange}
            />
            <hr />
            <Products
              products={this.state.filteredProducts}
              handleAddToCart={this.handleAddToCart}
            />
          </div>
          <div className="col-md-3">
            <Basket
              cartItems={this.state.cartItems}
              handleRemoveFromCart={this.handleRemoveFromCart}
            />
          </div>
        </div>
      </div>
    );
  }
}
export default App;
