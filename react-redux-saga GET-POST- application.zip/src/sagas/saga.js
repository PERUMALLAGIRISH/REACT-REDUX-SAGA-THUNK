import { takeLatest, call, put, take } from "redux-saga/effects";
import { fetchData, createPostData } from "../api";
import * as actions from "../actions/action";

// worker thread
function* getApiData() {
  try {
    // do an api call
    const data = yield call(fetchData);
    yield put({ type: "RECEIVE_API_DATA", data: data });
  } catch (e) {
    console.log(e);
  }
}

// worker thread
function* createPostApi(postData) {
  try {
    // do an api call
    console.log(postData.title);
    const data = yield call(createPostData, postData);
    yield put({ type: "RECEIVE_POST_CREATED", data: data });
  } catch (e) {
    console.log(e);
  }
}

// watcher thread
export function* mySaga() {
  yield takeLatest("REQUEST_API_DATA", getApiData);
  const { post } = yield take(actions.CREATE_POST_REQUESTED);
  yield call(createPostApi, post);
}
