export const fetchData = async () => {
  try {
    const response = await fetch(`http://jsonplaceholder.typicode.com/posts`);
    const data = response.json();
    return data;
  } catch (e) {
    console.log(e);
  }
};

export const createPostData = async postData => {
  console.log("In create post api" + postData.body);
  const response = await fetch("http://jsonplaceholder.typicode.com/posts", {
    method: "post",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json"
    },
    body: JSON.stringify(postData)
  });
  const data = response.json();
  return data;
};
