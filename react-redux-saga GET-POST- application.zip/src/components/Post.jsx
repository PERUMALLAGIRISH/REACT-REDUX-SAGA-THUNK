import React, { Component } from "react";
import { connect } from "react-redux";

class Post extends Component {
  componentWillMount() {
    this.props.requestApiData();
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.newPost) {
      this.props.posts.unshift(nextProps.newPost); // updating an existing array
    }
  }

  render() {
    return (
      <div>
        {this.props.posts.map(post => (
          <div key={post.id}>
            <h4>{post.title}</h4>
            <p>{post.body}</p>
          </div>
        ))}
      </div>
    );
  }
}

const mapStatetoProps = state => ({
  posts: state.posts.items,
  newPost: state.posts.item
});

const mapDispatchToProps = dispatch => {
  return {
    requestApiData: () => dispatch({ type: "REQUEST_API_DATA" })
  };
};

// map the state from the reducer to the props
export default connect(mapStatetoProps, mapDispatchToProps)(Post);
