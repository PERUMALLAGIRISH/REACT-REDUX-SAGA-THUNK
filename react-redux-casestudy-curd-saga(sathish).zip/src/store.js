import { createStore, applyMiddleware } from "redux";
import createSagaMiddleware from "redux-saga";
import { mySaga, mySagaGetEdit, mySagaEdit, mySagaDelete } from "./sagas/saga";
import rootReducer from "./reducers";

const sagaMiddleware = createSagaMiddleware();
const store = createStore(rootReducer, applyMiddleware(sagaMiddleware));

sagaMiddleware.run(mySaga);
sagaMiddleware.run(mySagaGetEdit);
sagaMiddleware.run(mySagaEdit);
sagaMiddleware.run(mySagaDelete);

export default store;