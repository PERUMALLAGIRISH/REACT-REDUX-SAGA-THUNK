import { takeLatest, call, put, take } from "redux-saga/effects";
import { fetchData, addProductData, fetchEditProductData, editProductData, deleteProductData } from "../api";
import * as actions from "../actions/action";

// worker thread
function* getApiData() {
  try {
    // do an api call
    const data = yield call(fetchData);
    yield put({ type: "RECEIVE_API_DATA", data: data });
  } catch (exe) {
    console.log("getApiData - Error->"+exe);
  }
}

// worker thread
function* addProductApi(productData) {
  try {
    // do an api call
    console.log("addProductApi:"+productData.id);
    const data = yield call(addProductData, productData);
    yield put({ type: "RECEIVE_PRODUCT_CREATED", data: data });
  } catch (exe) {
    console.log("addProductApi - Error ->"+exe);
  }
}

function* getEditProductData(id) {
  try {
    console.log("getEditProductData- id:"+id);
    // do an api call
    const data = yield call(fetchEditProductData, id);
    yield put({ type: "RECEIVE_EDIT_PRD_DATA", data: data });
  } catch (exe) {
    console.log("getEditProductData -Error ->"+exe);
  }
}


// worker thread
function* editProductApi(productData) {
  try {
    // do an api call
    console.log("editProductApi:"+productData);
    const data = yield call(editProductData, productData);
    yield put({ type: "RECEIVE_PRODUCT_EDITED", data: data });
  } catch (exe) {
    console.log("editProductApi -Error->"+exe);
  }
}

// worker thread
function* deleteProductApi(productId) {
  try {
    // do an api call
    console.log("deleteProductApi:"+productId);
    const data = yield call(deleteProductData, productId);
    yield put({ type: "RECEIVE_PRODUCT_DELETED", data: data });
  } catch (exe) {
    console.log("deleteProductApi -Error->"+exe);
  }
}

// watcher thread
export function* mySaga() {
  yield takeLatest("REQUEST_API_DATA", getApiData);
  const { product } = yield take(actions.ADD_PRODUCT_REQUESTED);
  yield call(addProductApi, product); 
}

// watcher thread
export function* mySagaEdit() { 
  const { product } = yield take(actions.EDIT_PRODUCT_REQUESTED);
  yield call(editProductApi, product);
}

// watcher thread
export function* mySagaGetEdit() {  
  const { id } = yield take(actions.FETCH_EDIT_PRODUCT_REQUESTED);
  yield call(getEditProductData, id);
}

// watcher thread
export function* mySagaDelete() { 
  const { id } = yield take(actions.DELETE_PRODUCT_REQUESTED);
  yield call(deleteProductApi, id);
}
