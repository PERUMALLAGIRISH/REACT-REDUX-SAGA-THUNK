import React, {Component} from 'react';
import './App.css';
import { Provider } from "react-redux";

import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

import ProductList from './Components/ProductList';
import AddProduct from "./Components/AddProduct";
import EditProduct from "./Components/EditProduct";


import store from "./store";

class App extends Component {
  
  render(){
    return (
      <div className="App">
      
      <Provider store={store}>
        
        <Router>
        { <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="#">
        <Link to={"/"}
                        
                    >
                        Home
                    </Link></a>

      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Features</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Contact</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="#">About</a>
      </li>
    </ul>
  </div>
</nav> }
          <div className="container">
            <Switch>
              <Route exact path="/" component={ProductList} />
              <Route path="/addProduct" component={AddProduct} />
              <Route path="/edit/:id" component={EditProduct} />
              <Route path="/productList" component={ProductList} />
            </Switch>
          </div>
        </Router>
      </Provider>
      </div>
    );
  }
}

export default App;
