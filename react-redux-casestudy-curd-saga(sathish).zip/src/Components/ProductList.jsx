import React, { Component } from 'react';
import { connect } from "react-redux";
import Pagination from './Pagination';
import { deleteProductAction } from "../actions/action";
import { Link } from "react-router-dom";


class ProductList extends Component {
    constructor(props) {
        super(props);
        this.state = {                       
            pageOfItems: []
        };
      
        this.onChangePage = this.onChangePage.bind(this);
    }

    onChangePage(pageOfItems) {
        // update state with new page of items
        this.setState({ pageOfItems: pageOfItems });
    }

    componentDidMount() {              
        this.props.requestApiData();
    }
        
    componentWillReceiveProps(nextProps) {
        if (nextProps.newProduct) {
            this.props.products.unshift(nextProps.newProduct); // updating an existing array
        }
    }

    navigateToNext = props => {
        this.props.history.push("/addProduct");
    };

    render(){
        const productItems =
            this.state.pageOfItems.map(product => (
            <tr key={product.id}>
                <td>{product.id}</td>
                <td>{product.name}</td>
                <td>{product.description}</td>
                <td>{product.price}</td>
                <td>
                    <Link
                        to={"/edit/" + product.id}
                        className="btn btn-primary"
                    >
                        Edit
                    </Link>
                     &nbsp;                
                    <button
                        onClick={() => this.props.deleteProductObj(product.id)}
                        className="btn btn-danger"
                    >
                        Delete
                    </button>
                </td>
            </tr>
            ))
        
        return(
            <React.Fragment>
               <div> <h1>Welcome to Product Application</h1></div>
                 <div className="table-responsive">
                    <table className="table table-striped table-bordered">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Price</th>
                            <th>Action</th>                           
                        </tr>
                        </thead>
                        <tbody className="table">
                            {productItems}                        
                        </tbody>                                          
                       
                    </table>
                    <div>
                        <Pagination items={this.props.products} onChangePage={this.onChangePage} />
                    </div>
                </div>
                <div className="text-center">
                    <button 
                        className="btn btn-success btn-small m-2"
                        onClick={() => this.navigateToNext(this.props)}                                 
                    > 
                        Add Product</button>
                </div>
            </React.Fragment>
        );
    }
}


const mapStatetoProps = state => ({
    products: state.products.items,
    newProduct: state.products.item
});
  
const mapDispatchToProps = dispatch => {
    return {
      requestApiData: () => dispatch({ type: "REQUEST_API_DATA" }),
      deleteProductObj: id => dispatch(deleteProductAction(id))
    };
};
  
// map the state from the reducer to the props
export default connect(mapStatetoProps, mapDispatchToProps)(ProductList);