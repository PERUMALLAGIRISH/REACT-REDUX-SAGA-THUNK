import React, { Component } from 'react';
import { connect } from "react-redux";
import { addProductAction } from "../actions/action";

class AddProduct extends Component{

    state = {
        id: "",        
        name: "",        
        description: "",        
        price: "",
        nameValid: false,
        priceValid: false,       
        formErrors: { 
            id: "", name:"", description:"", price: "" 
        },
        formValid: false
    }
        
    handleChange = (e) => {           
        this.setState({[e.target.name]: e.target.value })
        this.validateField(e.target.name, e.target.value)       
    }


    validateField(fieldName, value) {    
        let nameValid = this.state.nameValid;
        let priceValid = this.state.priceValid;    
        let fieldValidationErrors = this.state.formErrors;
        console.log("validateField:: fieldName:"+fieldName+" Value:"+value);
        switch (fieldName) {    
    
            case "name":    
                nameValid = value.match(/^[A-Za-z]+$/);
                fieldValidationErrors.name = nameValid ? " " : "Please enter strings";
                  
            break;
       
            case "price":    
                priceValid = value.match(/^[0-9]*$/);    
                fieldValidationErrors.price = priceValid ? " " : "Please enter number";
                
            break;    
            default:    
            break;    
        }
            
        this.setState({
                formErrors: fieldValidationErrors,            
                nameValid: nameValid,           
                priceValid:priceValid
            },    
            this.validateForm   
        );    
    }
    
    validateForm() {        
        this.setState({        
            formValid: this.state.nameValid &&
            this.state.priceValid    
        });  
        console.log("ValidateForm: formValid :"+this.state.formValid)  
    }
        
    handleSubmit = (e) => {        
        e.preventDefault(); 
             
        const product = {
            name: this.state.name,            
            description: this.state.description,            
            price: this.state.price
        }
        this.props.addProduct(product);
        //this.props.history.push("/");
    }

    render(){
        return(
            <React.Fragment>
                    <div className="text-center col-md-12">
                <h4 >Add New Product</h4> </div>
                <div className="row">                
                    <div className="col-md-3"/>
                    <div className="col-md-6">
                        <form onSubmit={this.handleSubmit}>
                            
                            <div className="form-group row">
                                <label className="col-sm-4 col-form-label">Name:</label>
                                <div className="col-sm-8">
                                    <input
                                        type="text"
                                        name="name"
                                        value={this.state.name}
                                        onChange={this.handleChange}
                                    />
                                    <h6 className="text-danger">{this.state.formErrors.name}</h6>
                                </div>
                            </div>
                            <div className="form-group row">
                                <label className="col-sm-4 col-form-label">Description:</label>
                                <div className="col-sm-8">
                                    <input
                                        type="text"
                                        name="description"
                                        value={this.state.description}
                                        onChange={this.handleChange}
                                    />
                                    
                                </div>
                            </div>
                            <div className="form-group row">
                                <label className="col-sm-4 col-form-label">Price:</label>
                                <div className="col-sm-8">
                                    <input
                                        type="text"
                                        name="price"
                                        value={this.state.price}
                                        onChange={this.handleChange}
                                    />
                                    <h6 className="text-danger">{this.state.formErrors.price}</h6>
                                </div>
                            </div>
                            <div className="text-center">
                                <button
                                    className="btn btn-success" disabled={!this.state.formValid}
                                >Submit</button>
                            </div>

                        </form>
                    </div>
                </div>            
            </React.Fragment>
        );
    }
}

const mapDispatchToProps = dispatch => {
    return {
        addProduct: product => dispatch(addProductAction(product))
    };
};
  
export default connect(null, mapDispatchToProps)(AddProduct);