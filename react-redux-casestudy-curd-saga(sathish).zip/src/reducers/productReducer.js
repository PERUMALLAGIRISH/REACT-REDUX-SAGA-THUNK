const initialState = {
  items: [],
  item: {}
};

export default function(state = initialState, action) {
  switch (action.type) {
    case "RECEIVE_API_DATA":
      return {
        // state mutates here
        ...state,
        items: action.data
      };
    case "RECEIVE_PRODUCT_CREATED":
      return {
        // state mutates here
        ...state,
        item: action.data
      };
    case "RECEIVE_EDIT_PRD_DATA":
        return {
          // state mutates here
          ...state,
          item: action.data
        };
    case "RECEIVE_PRODUCT_EDITED":
      return {
        // state mutates here
        ...state,
        item: action.data
      };
    case "RECEIVE_PRODUCT_DELETED":
      return {
        // state mutates here
        ...state,
        item: action.data
      };
    default:
      return state;
  }
}
