import React, {Component} from 'react';
import './App.css';
import { Provider } from "react-redux";

import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

import ProductList from './Components/ProductList';
import AddProduct from "./Components/AddProduct";
import EditProduct from "./Components/EditProduct";

import store from "./store";

class App extends Component {
  
  render(){
    return (
      <div className="App">
      <Provider store={store}>
        <h2 className="text-center">React Redux Saga CRUD Application</h2>
        <Router>
          <div className="container">
            <Switch>
              <Route exact path="/" component={ProductList} />
              <Route path="/addProduct" component={AddProduct} />
              <Route path="/edit/:id" component={EditProduct} />
              <Route path="/productList" component={ProductList} />
            </Switch>
          </div>
        </Router>
      </Provider>
      </div>
    );
  }
}

export default App;
