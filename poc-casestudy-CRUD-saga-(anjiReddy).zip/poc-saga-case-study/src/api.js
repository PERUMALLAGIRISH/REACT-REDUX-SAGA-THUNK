export const fetchData = async () => {
  try {
    const response = await fetch(`http://localhost:8000/products`);
    const data = response.json();
    return data;
  } catch (exe) {
    console.log("fectData - Error->"+exe);
  }
};

export const addProductData = async productData => {
  console.log("In add product api" + productData);
  try{
    const response = await fetch("http://localhost:8000/products", {
      method: "post",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(productData)
    });
    const data = response.json();
    return data;
  }catch(exe){
    console.log("addProductData - Error->"+exe);
  }  
};

export const fetchEditProductData = async id => {
  console.log("In fetch edit product api" + id);
  try {
    const data = await fetch("http://localhost:8000/products/"+id)
                .then(response => response.json());
   
    console.log("In fetch edit product data" + data);
    return data;
  } catch (exe) {
    console.log("fetchEditProductData - Error->"+exe);
  }
};

export const editProductData = async productData => {
  console.log("In edit product api" + productData);
  try{
    const response = await fetch("http://localhost:8000/products/"+productData.id, {
      method: "put",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(productData)
    });
    const data = response.json();
    return data;
  }catch(exe){
    console.log("editProductData - Error->"+exe);
  }
  
};

export const deleteProductData = async id => {
  console.log("In delete product api" + id);
  try{
    const response = await fetch("http://localhost:8000/products/"+id, {
      method: "delete",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      }
    });
    const data = response.json();
    return data;
  }catch(exe){
    console.log("deleteProductData - Error->"+exe);
  }  
};