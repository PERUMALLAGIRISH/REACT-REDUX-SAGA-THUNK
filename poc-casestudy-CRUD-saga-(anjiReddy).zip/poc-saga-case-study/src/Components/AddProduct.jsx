import React, { Component } from 'react';
import { connect } from "react-redux";
import { addProductAction } from "../actions/action";

class AddProduct extends Component{

    state = {
        id: "",        
        name: "",        
        description: "",        
        price: "",
        idValid: false,
        nameValid: false,
        descriptionValid:false,
        priceValid: false,       
        formErrors: { 
            id: "", name:"", description:"", price: "" 
        },
        formValid: false
    }
        
    handleChange = (e) => {           
        this.setState({[e.target.name]: e.target.value })
        this.validateField(e.target.name, e.target.value)       
    }


    validateField(fieldName, value) {    
        let idValid = this.state.idValid;   
        let nameValid = this.state.nameValid;
        let descriptionValid = this.state.descriptionValid;
        let priceValid = this.state.priceValid;    
        let fieldValidationErrors = this.state.formErrors;
        console.log("validateField:: fieldName:"+fieldName+" Value:"+value);
        switch (fieldName) {    
            case "id":   
                idValid = value.match(/^[0-9]*$/) && value.length <= 2;    
                fieldValidationErrors.id = idValid ? " " : "Please enter only number less than 100";
                console.log(fieldValidationErrors.id);    
            break;
    
            case "name":    
                nameValid = value.match(/^[A-Za-z]+$/);
                fieldValidationErrors.name = nameValid ? " " : "Please enter only strings";
                console.log(fieldValidationErrors.name);   
            break;
    
            case "description":
                descriptionValid = value.match(/^[A-Za-z]+$/);                 
                fieldValidationErrors.description = descriptionValid ? " " : "Please enter only strings";
                console.log(fieldValidationErrors.description);    
            break;
    
            case "price":    
                priceValid = value.match(/^[0-9]*$/) && value.length <= 3;    
                fieldValidationErrors.price = priceValid ? " " : "Please enter only price less than 1000";
                console.log(fieldValidationErrors.price);
            break;    
            default:    
            break;    
        }
            
        this.setState({
                formErrors: fieldValidationErrors,            
                idValid: idValid,
                nameValid: nameValid,           
                descriptionValid: descriptionValid,
                priceValid:priceValid
            },    
            this.validateForm   
        );    
    }
    
    validateForm() {        
        this.setState({        
            formValid: this.state.idValid &&
            this.state.nameValid &&
            this.state.descriptionValid &&
            this.state.priceValid    
        });  
        console.log("ValidateForm: formValid :"+this.state.formValid)  
    }
        
    handleSubmit = (e) => {        
        e.preventDefault(); 
             
        const product = {
            id: this.state.id,            
            name: this.state.name,            
            description: this.state.description,            
            price: this.state.price
        }
        this.props.addProduct(product);
        this.props.history.push("/");
    }

    render(){
        return(
            <React.Fragment>
                <h2 className="text-center">Add New Product</h2>
                <div className="row">                
                    <div className="col-md-3"/>
                    <div className="col-md-6">
                        <form onSubmit={this.handleSubmit}>
                            <div className="form-group row">
                                <label className="col-sm-4 col-form-label">ID:</label>
                                <div className="col-sm-8">
                                    <input
                                        type="text"
                                        name="id" 
                                        value={this.state.id}
                                        onChange={this.handleChange}
                                    />
                                    <h6 className="text-danger">{this.state.formErrors.id}</h6>
                                </div>
                            </div>
                            <div className="form-group row">
                                <label className="col-sm-4 col-form-label">Name:</label>
                                <div className="col-sm-8">
                                    <input
                                        type="text"
                                        name="name"
                                        value={this.state.name}
                                        onChange={this.handleChange}
                                    />
                                    <h6 className="text-danger">{this.state.formErrors.name}</h6>
                                </div>
                            </div>
                            <div className="form-group row">
                                <label className="col-sm-4 col-form-label">Description:</label>
                                <div className="col-sm-8">
                                    <input
                                        type="text"
                                        name="description"
                                        value={this.state.description}
                                        onChange={this.handleChange}
                                    />
                                    <h6 className="text-danger">{this.state.formErrors.description}</h6>
                                </div>
                            </div>
                            <div className="form-group row">
                                <label className="col-sm-4 col-form-label">Price:</label>
                                <div className="col-sm-8">
                                    <input
                                        type="text"
                                        name="price"
                                        value={this.state.price}
                                        onChange={this.handleChange}
                                    />
                                    <h6 className="text-danger">{this.state.formErrors.price}</h6>
                                </div>
                            </div>
                            <div className="text-center">
                                <button
                                    className="btn btn-success" disabled={!this.state.formValid}
                                >Submit</button>
                            </div>

                        </form>
                    </div>
                </div>            
            </React.Fragment>
        );
    }
}

const mapDispatchToProps = dispatch => {
    return {
        addProduct: product => dispatch(addProductAction(product))
    };
};
  
export default connect(null, mapDispatchToProps)(AddProduct);