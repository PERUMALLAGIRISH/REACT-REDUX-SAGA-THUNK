import React, { Component } from 'react';
import { connect } from "react-redux";
import { getEditProduct, editProductAction } from "../actions/action";

class EditProduct extends Component {

    _isMounted = false;
    state = {
        id: "",
        name: "", 
        description: "",
        price: "",     
        nameValid: true,
        descriptionValid:true,
        priceValid: true, 
        formErrors: { 
            id: "", name:"", description:"", price: "" 
        },
        formValid: false
    };
       
    componentDidMount() {
        this._isMounted = true;
        console.log("EditProduct - id:"+this.props.match.params.id);
        this.props.getEditProductObj(this.props.match.params.id); 
        console.log("EditProduct - product 000:"+this.props.editProduct.id); 
        console.log("EditProduct - product name 000:"+this.props.editProduct.name); 
        if(this.props.editProduct.id){
            this.setState({
                id:this.props.editProduct.id,
                name:this.props.editProduct.name,
                description:this.props.editProduct.description,
                price:this.props.editProduct.price
            }) 
        }             
    }

    componentDidUpdate() {        
        if (this._isMounted) {
            //Checking here for the editProduct data is present        
            if(this.props.editProduct.id){
                this.setState({
                    id:this.props.editProduct.id,
                    name:this.props.editProduct.name,
                    description:this.props.editProduct.description,
                    price:this.props.editProduct.price
                });
                this._isMounted = false;
            }
            
        }     
    }
  
    componentWillUnmount() {
        this._isMounted = false;
     }
            
    handleChange = (e) => {        
        this.setState({[e.target.name]: e.target.value })
        this.validateField(e.target.name, e.target.value)    
    }
    
    validateField(fieldName, value) {       
        let nameValid = this.state.nameValid;
        let descriptionValid = this.state.descriptionValid;
        let priceValid = this.state.priceValid;    
        let fieldValidationErrors = this.state.formErrors;
        console.log("validateField:: fieldName:"+fieldName+" Value:"+value);
        switch (fieldName) {            
            case "name":    
                nameValid = value.match(/^[A-Za-z]+$/);
                fieldValidationErrors.name = nameValid ? " " : "Please enter only strings";
                console.log(fieldValidationErrors.name);   
            break;
    
            case "description":
                descriptionValid = value.match(/^[A-Za-z]+$/);                 
                fieldValidationErrors.description = descriptionValid ? " " : "Please enter only strings";
                console.log(fieldValidationErrors.description);    
            break;
    
            case "price":    
                priceValid = value.match(/^[0-9]*$/) && value.length <= 3;    
                fieldValidationErrors.price = priceValid ? " " : "Please enter only price less than 1000";
                console.log(fieldValidationErrors.price);
            break;    
            default:    
            break;    
        }
            
        this.setState({
                formErrors: fieldValidationErrors, 
                nameValid: nameValid,           
                descriptionValid: descriptionValid,
                priceValid:priceValid
            },    
            this.validateForm   
        );    
    }
    
    validateForm() {        
        this.setState({        
            formValid: 
            this.state.nameValid &&
            this.state.descriptionValid &&
            this.state.priceValid    
        });  
        console.log("ValidateForm: formValid :"+this.state.formValid)  
    }
    
    handleUpdate = (e) => {        
        e.preventDefault(); 
        console.log("ID:: "+this.state.id);
        console.log("Name:: "+this.state.name);
        console.log("Desc:: "+this.state.description);
        const product = {    
            id: this.state.id,           
            name: this.state.name,            
            description: this.state.description,            
            price: this.state.price
        }
        this.props.editProductObj(product);
        this.props.history.push("/");
    }

    render(){
        
        return(
            <React.Fragment>
                <h2 className="text-center">Edit Product</h2>
                <div className="row">                
                    <div className="col-md-3"/>
                    <div className="col-md-6">
                        <form onSubmit={this.handleUpdate}>                            
                            <div className="form-group row">
                                <label className="col-sm-4 col-form-label">Name:</label>
                                <div className="col-sm-8">
                                    <input
                                        type="text"
                                        name="name"
                                        value={this.state.name}
                                        onChange={this.handleChange}
                                    />
                                    <h6 className="text-danger">{this.state.formErrors.name}</h6>
                                </div>
                            </div>
                            <div className="form-group row">
                                <label className="col-sm-4 col-form-label">Description:</label>
                                <div className="col-sm-8">
                                    <input
                                        type="text"
                                        name="description"
                                        value={this.state.description}
                                        onChange={this.handleChange}
                                    />
                                    <h6 className="text-danger">{this.state.formErrors.description}</h6>
                                </div>
                            </div>
                            <div className="form-group row">
                                <label className="col-sm-4 col-form-label">Price:</label>
                                <div className="col-sm-8">
                                    <input
                                        type="text"
                                        name="price"
                                        value={this.state.price}
                                        onChange={this.handleChange}
                                    />
                                    <h6 className="text-danger">{this.state.formErrors.price}</h6>
                                </div>
                            </div>
                            <div className="text-center">
                                <button
                                    className="btn btn-success" type="submit"
                                >Update</button>
                            </div>

                        </form>
                    </div>
                </div>            
            </React.Fragment>
        );
    }
}

const mapStatetoProps = state => ({
    products : state.products.items,   
    editProduct: state.products.item   
});

const mapDispatchToProps = dispatch => {
    return {
        getEditProductObj: id => dispatch(getEditProduct(id)),
        editProductObj: product => dispatch(editProductAction(product))
    };
};
  
export default connect(mapStatetoProps, mapDispatchToProps)(EditProduct);