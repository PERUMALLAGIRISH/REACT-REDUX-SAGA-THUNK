export const ADD_PRODUCT_REQUESTED = "ADD_PRODUCT_REQUESTED";

export const addProductAction = product => ({
  type: ADD_PRODUCT_REQUESTED,
  product
});

export const FETCH_EDIT_PRODUCT_REQUESTED = "FETCH_EDIT_PRODUCT_REQUESTED";

export const getEditProduct = id => ({
  type: FETCH_EDIT_PRODUCT_REQUESTED,
  id
});

export const EDIT_PRODUCT_REQUESTED = "EDIT_PRODUCT_REQUESTED";

export const editProductAction = product => ({
  type: EDIT_PRODUCT_REQUESTED,
  product
});

export const DELETE_PRODUCT_REQUESTED = "DELETE_PRODUCT_REQUESTED";

export const deleteProductAction = id => ({
  type: DELETE_PRODUCT_REQUESTED,
  id
});
