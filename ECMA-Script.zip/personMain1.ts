import { Programmer1 } from "./person1";

let p1 = new Programmer1("Sally", 27, "Node JS");
let p2 = new Programmer1("Bucky", 29, "React JS");

p1.displayPersonalDetails();
p1.displayLanguage();

p2.displayPersonalDetails();
p2.displayLanguage();
