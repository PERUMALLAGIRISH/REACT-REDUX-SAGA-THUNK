"use strict";
exports.__esModule = true;
var person1_1 = require("./person1");
var p1 = new person1_1.Programmer1("Sally", 27, "Node JS");
var p2 = new person1_1.Programmer1("Bucky", 29, "React JS");
p1.displayPersonalDetails();
p1.displayLanguage();
p2.displayPersonalDetails();
p2.displayLanguage();
